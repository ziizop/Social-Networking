//
//  FriendsRouter.swift
//  Social Networking
//
//  Created by Anastas Smekh on 28.02.2021.
//

import Foundation

protocol FriendsRouterInput {
    
}

final class FriendsRouter {
    weak var view: FriendsViewInput?
}

extension FriendsRouter: FriendsRouterInput {
    
}
