
enum TypeSection: Int, CaseIterable {
    case searchBar
    case storys
    case post 
}
