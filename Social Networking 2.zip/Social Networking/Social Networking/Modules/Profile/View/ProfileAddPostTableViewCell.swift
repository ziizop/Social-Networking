//
//  ProfileAddPostTableViewCell.swift
//  Social Networking
//
//  Created by Anastas Smekh on 07.03.2021.
//

import UIKit

class ProfileAddPostTableViewCell: UITableViewCell {
    
    private lazy var inputTextFild: UITextField = {
        let textFild = UITextField()
        textFild.placeholder = "Добавить пост"
        return textFild
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        configureView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureView() {
        contentView.addSubview(inputTextFild)
        inputTextFild.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(5)
            make.top.bottom.equalToSuperview().inset(3)
        }
    }
    
}
