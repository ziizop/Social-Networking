//
//  ProfileView.swift
//  Social Networking
//
//  Created by Anastas Smekh on 27.02.2021.
//

import UIKit

protocol ProfileViewOutput {
    func viewDidLoad()
    func viewDidAppear()
    func numberOfSections() -> Int
    func numberOfRowsInSection(section: UserPageTypeSection) -> Int
    func cellForRowAt(section: UserPageTypeSection, indexRow: Int) -> UserCollectedData?
    func heightForRowAt(_ section: UserPageTypeSection) -> CGFloat
}

protocol ProfileViewInput: class {
    func reloadData()
    
}
final class ProfileView: BaseViewController {
    
    var presenter: ProfileViewOutput?
    
    private lazy var tableView: UITableView = {
        let tableView: UITableView
        if #available(iOS 13.0, *) {
            tableView = UITableView(frame: .zero, style: .insetGrouped)
        } else {
            tableView = UITableView(frame: .zero, style: .grouped)
        }
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(cellWithClass: ProfileInfoTableViewCell.self)
        tableView.register(cellWithClass: ProfileAddPostTableViewCell.self)
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter?.viewDidLoad()
        configure()
        view.backgroundColor = .yellow
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        presenter?.viewDidAppear()
    }
    
    private func configure() {
        view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.width.height.equalToSuperview()
        }
        navigationItem.title = "Anastas"
    }
    
}

//MARK: - ProfileViewInput

extension ProfileView: ProfileViewInput {
    func reloadData() {
        tableView.reloadData()
    }
}

//MARK: - UITableViewDelegate
extension ProfileView: UITableViewDelegate {
    
}

//MARK: - UITableViewDataSource
extension ProfileView: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        presenter?.numberOfSections() ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let section = UserPageTypeSection(rawValue: section) else { return 0 }
        return presenter?.numberOfRowsInSection(section: section) ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ProfileInfoTableViewCell.reuseIdentifier, for: indexPath) as? ProfileInfoTableViewCell,
              let section = UserPageTypeSection(rawValue: indexPath.section),
              let data = presenter?.cellForRowAt(section: section, indexRow: indexPath.row)
              else { return UITableViewCell() }
        switch data.type {
        case.userAddPost:
            cell.addPostUser()
        case .userPost:
            cell.post(text: "Test")
        case .some(.userInfo):
            print("data")
        default:
            print("default")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        <#code#>
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        guard let section = UserPageTypeSection(rawValue: indexPath.section) else { return 0 }
        return presenter?.heightForRowAt(section) ?? 0
    }
}
