//
//  ProfileInteractor.swift
//  Social Networking
//
//  Created by Anastas Smekh on 01.03.2021.
//

import Foundation

protocol ProfileInteractorOutput: class {
    func userAllArray(_ data: [UserCollectedData]?)
}

protocol ProfileInteractorInput {
    func factoryUserData()
    func dataCollection()
}

final class ProfileInteractor {
    weak var presenter: ProfileInteractorOutput?
    private var dataArrays: [UserCollectedData]?
}

//MARK: - ProfileInteractorInput
extension ProfileInteractor: ProfileInteractorInput {
    
    /*
     Загружаем данные с сервера и компонуем  объекты для передачи на presenter
     */
    func factoryUserData() {
        var dataArray: [UserCollectedData] = []
        var userID = AuthManager.shared.userId
        NetworkingService.shared.userProfil(userID) { [weak self] (result) in
            guard let self = self else { return }
            switch result {
            case .success(let dataUser):
                print("Данные user: \n \(dataUser)")
                var userInfoData = UserCollectedData(type: .userInfo, data: dataUser, heightRow: 680)
                var userAddPost = UserCollectedData(type: .userAddPost, data: [1], heightRow: 60)
                var userPost = UserCollectedData(type: .userPost, data: [1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4], heightRow: 300)
                dataArray = [userInfoData, userAddPost, userPost]
                self.presenter?.userAllArray(dataArray)
                self.dataArrays = dataArray
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    /*
     передача заполненного  массива данных на presenter
     */
    func dataCollection() {
        presenter?.userAllArray(dataArrays)
    }
}
