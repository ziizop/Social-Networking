//
//  ProfilePresenter.swift
//  Social Networking
//
//  Created by Anastas Smekh on 01.03.2021.
//

import UIKit

final class ProfilePresenter {
    weak var view: ProfileViewInput?
    var interactor: ProfileInteractorInput?
    var router: ProfileRouterInput?
    
    private var userData: [UserCollectedData]? = []
}

//MARK: - ProfileViewOutput
extension ProfilePresenter: ProfileViewOutput {
    
    func viewDidLoad() {
        interactor?.dataCollection()
    }
    
    func viewDidAppear() {
        interactor?.factoryUserData()
    }
    
    func numberOfSections() -> Int {
        UserPageTypeSection.allCases.count
    }
    
    func numberOfRowsInSection(section: UserPageTypeSection) -> Int {
        userData?[section.rawValue].data?.count ?? 0
    }
    
    func cellForRowAt(section: UserPageTypeSection, indexRow: Int) -> UserCollectedData? {
        userData?[section.rawValue]
    }
    
    func heightForRowAt(_ section: UserPageTypeSection) -> CGFloat {
        userData?[section.rawValue].heightRow ?? 0
    }
    
}

//MARK: - ProfileInteractorOutput
extension ProfilePresenter: ProfileInteractorOutput {
    func userAllArray(_ data: [UserCollectedData]?) {
        userData = data
        view?.reloadData()
    }
}
