//
//  WebPageRouter.swift
//  Social Networking
//
//  Created by Anastas Smekh on 01.03.2021.
//

import Foundation

protocol WebPageRouterInput {
    func startTransit(token: String)
}

final class WebPageRouter {
    weak var view: WebPageViewInput?
}

extension WebPageRouter: WebPageRouterInput {
    func startTransit(token: String) {
        let tabBar = TabBarAssembly.assembly(news: token)
        view?.navigationController?.pushViewController(tabBar, animated: true)
    }
    
    
}
