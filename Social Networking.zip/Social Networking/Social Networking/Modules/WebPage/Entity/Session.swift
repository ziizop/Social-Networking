import Foundation

class Session {
    static let shared = Session()
    
    var token = ""
    var userId = Int()
    
    private init() {
        
    }
}
