//
//  PrimaryUserData.swift
//  Social Networking
//
//  Created by Anastas Smekh on 04.03.2021.
//

import Foundation

struct PrimaryUserData {
    var token: String
    var userId: String
}
