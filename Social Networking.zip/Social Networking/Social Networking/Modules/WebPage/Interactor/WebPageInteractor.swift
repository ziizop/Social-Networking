//
//  WebPageInteractor.swift
//  Social Networking
//
//  Created by Anastas Smekh on 01.03.2021.
//

import Foundation

protocol WebPageInteractorOutput: class {
    func requestForLogin(_ request: URLRequest)
}

protocol WebPageInteractorInput {
    func transinReguest()
}

final class WebPageInteractor {
    weak var presenter: WebPageInteractorOutput?
}

extension WebPageInteractor: WebPageInteractorInput {
    
    func transinReguest() {
        let api = NetworkongService.shared
        
        api.login { [ weak self ] result in
            guard let self = self else { return }
            switch result {
            case .success(let request):
                print(request)
                self.presenter?.requestForLogin(request)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
