//
//  NewsPresenter.swift
//  Social Networking
//
//  Created by Anastas Smekh on 27.02.2021.
//

import Foundation

final class NewsPresenter {
    weak var view: NewsViewInput?
    var interactor: NewsInteractorInput?
    var router: NewsRouterInput?
    private var token: String?
    private var newsArry: [NewsRow] = []
    
    
    init(tokens: String) {
        token = tokens
    }
}

extension NewsPresenter: NewsViewOutput {
    
    func viewDidLoad() {
    }
    
    func viewWillAppear() {
        interactor?.factoryNews()
    }
    
    func viewDidAppear() {
       
    }
    
    func numberOfRowsInSection() -> Int {
        newsArry.count
    }
    
    func cellForRowAt(indexRow: Int) -> NewsRow {
        newsArry[indexRow]
    }
}

extension NewsPresenter: NewsInteractorOutput {
    func newsDataJson(_ data: NewsAllData) {
        newsArry = data.response.items
        view?.reloadData()
    }
}
