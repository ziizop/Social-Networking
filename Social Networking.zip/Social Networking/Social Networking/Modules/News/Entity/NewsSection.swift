
enum NewsSection: String, Codable {
    case searchBar
    case storys = "storys"
    case post = "post"
}
