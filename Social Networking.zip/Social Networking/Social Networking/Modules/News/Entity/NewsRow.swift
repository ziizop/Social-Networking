//
//  NewsRow.swift
//  Social Networking
//
//  Created by Anastas Smekh on 02.03.2021.
//

import Foundation

struct NewsRow: Codable {
    var id: Int?
    var name: String?
    var photo_100: String?
    var text: String?
//    var can_doubt_category: String?
//    var can_set_category: String?
//    var post_type: String?
//    var text: String
}
