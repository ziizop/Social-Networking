//
//  NewsAllData.swift
//  Social Networking
//
//  Created by Anastas Smekh on 02.03.2021.
//

import Foundation


struct NewsAllData: Codable {
    let response: Items
}

struct Items: Codable {
    var items: [NewsRow]
}
