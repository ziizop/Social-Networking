//
//  NewsInteractor.swift
//  Social Networking
//
//  Created by Anastas Smekh on 27.02.2021.
//

import Foundation

protocol NewsInteractorOutput: class {
    func newsDataJson(_ data: NewsAllData)
}

protocol NewsInteractorInput {
    func factoryNews()
}

final class NewsInteractor {
    weak var presenter: NewsInteractorOutput?
}

extension NewsInteractor: NewsInteractorInput {
    func factoryNews() {
        let token = "737ab1a088fd828105ba60092bc2c6291298be5ba79b63553616dd6b5e13b285db5d402fabd54f5426cc5"
        let api = NetworkongService.shared
        api.loadNews(token: token) {  result in
            switch result {
            case .success(let data):
                self.presenter?.newsDataJson(data)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
