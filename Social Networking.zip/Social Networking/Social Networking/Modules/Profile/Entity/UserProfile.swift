// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let userProfile = try? newJSONDecoder().decode(UserProfile.self, from: jsonData)

import Foundation
import SwiftyJSON

// MARK: - Response
class UserProfile: Codable {
//    let firstName: String
//    let id: Int
//    let lastName: String
//    let canAccessClosed, isClosed: Bool
//    let sex: Int
//    let screenName: String
//    let photo50, photo100: String
//    let online, verified, friendStatus: Int
//    let nickname, domain, bdate: String
//    let city, country: City
//    let timezone: Int
//    let photo200, photoMax, photo200_Orig, photo400_Orig: String
//    let photoMaxOrig: String
//    let photoID: String
//    let hasPhoto, hasMobile, isFriend, canPost: Int
//    let canSeeAllPosts, canSeeAudio: Int
//    let skype, interests, books, tv: String
//    let quotes, about, games, movies: String
//    let activities, music: String
//    let canWritePrivateMessage, canSendFriendRequest: Int
//    let canBeInvitedGroup: Bool
//    let mobilePhone, homePhone, site, status: String
//    let lastSeen: LastSeen
//    let cropPhoto: CropPhoto
//    let blacklisted, blacklistedByMe, isFavorite, isHiddenFromFeed: Int
//    let commonCount: Int
//    let career, military: [JSONAny]
//    let university: Int
//    let universityName: String
//    let faculty: Int
//    let facultyName: String
//    let graduation: Int
//    let homeTown: String
//    let relation: Int
//    let personal: Personal
//    let universities: [JSONAny]
//    let schools: [School]
//    let relatives: [Relative]
//
//    enum CodingKeys: String, CodingKey {
//        case firstName = "first_name"
//        case id
//        case lastName = "last_name"
//        case canAccessClosed = "can_access_closed"
//        case isClosed = "is_closed"
//        case sex
//        case screenName = "screen_name"
//        case photo50 = "photo_50"
//        case photo100 = "photo_100"
//        case online, verified
//        case friendStatus = "friend_status"
//        case nickname, domain, bdate, city, country, timezone
//        case photo200 = "photo_200"
//        case photoMax = "photo_max"
//        case photo200_Orig = "photo_200_orig"
//        case photo400_Orig = "photo_400_orig"
//        case photoMaxOrig = "photo_max_orig"
//        case photoID = "photo_id"
//        case hasPhoto = "has_photo"
//        case hasMobile = "has_mobile"
//        case isFriend = "is_friend"
//        case canPost = "can_post"
//        case canSeeAllPosts = "can_see_all_posts"
//        case canSeeAudio = "can_see_audio"
//        case skype, interests, books, tv, quotes, about, games, movies, activities, music
//        case canWritePrivateMessage = "can_write_private_message"
//        case canSendFriendRequest = "can_send_friend_request"
//        case canBeInvitedGroup = "can_be_invited_group"
//        case mobilePhone = "mobile_phone"
//        case homePhone = "home_phone"
//        case site, status
//        case lastSeen = "last_seen"
//        case cropPhoto = "crop_photo"
//        case blacklisted
//        case blacklistedByMe = "blacklisted_by_me"
//        case isFavorite = "is_favorite"
//        case isHiddenFromFeed = "is_hidden_from_feed"
//        case commonCount = "common_count"
//        case career, military, university
//        case universityName = "university_name"
//        case faculty
//        case facultyName = "faculty_name"
//        case graduation
//        case homeTown = "home_town"
//        case relation, personal, universities, schools, relatives
//    }

    init(from json: JSON) {
//        let firstName = json["first_name"].stringValue
//        let id = json["id"].intValue
//        let lastName = json["last_name"].stringValue
//        let canAccessClosed = json["can_access_closed"].boolValue
//        let isClosed = json["is_closed"].boolValue
//        let sex = json["sex"]
//        let screenName = json["screen_name"].stringValue
//        let photo50 = json["photo_50"].stringValue
//        let photo100 = json["photo_100"].stringValue
//        let online = json["online"].intValue
//        let verified = json["verified"].intValue
//        let friendStatus = json["friend_status"].intValue
//        let nickname = json
//        let domain = json
//        let bdate = json
//        let city = json
//        let country = json
//        let timezone = json
//        let photo200 = json"photo_200"
//        let photoMax = json"photo_max"
//        let photo200_Orig = json"photo_200_orig"
//        let photo400_Orig = json"photo_400_orig"
//        let photoMaxOrig = json"photo_max_orig"
//        let photoID = json"photo_id"
//        let hasPhoto = json"has_photo"
//        let hasMobile = json"has_mobile"
//        let isFriend = json"is_friend"
//        let canPost = json"can_post"
//        let canSeeAllPosts = json"can_see_all_posts"
//        let canSeeAudio = json"can_see_audio"
//        let skype = json
//        let interests = json
//        let books = json
//        let tv = json
//        let quotes = json
//        let about = json
//        let games = json
//        let movies = json
//        let activities = json
//        let music = json
//        let canWritePrivateMessage = json"can_write_private_message"
//        let canSendFriendRequest = json"can_send_friend_request"
//        let canBeInvitedGroup = json"can_be_invited_group"
//        let mobilePhone = json"mobile_phone"
//        let homePhone = json"home_phone"
//        let site = json
//        let status = json
//        let lastSeen = json"last_seen"
//        let cropPhoto = json"crop_photo"
//        let blacklisted = json
//        let blacklistedByMe = json"blacklisted_by_me"
//        let isFavorite = json"is_favorite"
//        let isHiddenFromFeed = json"is_hidden_from_feed"
//        let commonCount = json"common_count"
//        let career =
//        let military =
//        let university =
//        let universityName = json"university_name"
//        let faculty = json
//        let facultyName = json"faculty_name"
//        let graduation = json
//        let homeTown = json"home_town"
//        let relation = json
//        let personal = json
//        let universities = json
//        let schools = json
//        let relatives = json
    }
}

// MARK: - City
class City: Codable {
    let id: Int
    let title: String

    init(id: Int, title: String) {
        self.id = id
        self.title = title
    }
}

// MARK: - CropPhoto
class CropPhoto: Codable {
    let photo: Photo
    let crop, rect: Crop

    init(photo: Photo, crop: Crop, rect: Crop) {
        self.photo = photo
        self.crop = crop
        self.rect = rect
    }
}

// MARK: - Crop
class Crop: Codable {
    let x: Int
    let y: Double
    let x2: Int
    let y2: Double

    init(x: Int, y: Double, x2: Int, y2: Double) {
        self.x = x
        self.y = y
        self.x2 = x2
        self.y2 = y2
    }
}

// MARK: - Photo
class Photo: Codable {
    let albumID, date, id, ownerID: Int
    let hasTags: Bool
    let lat, long: Double
    let postID: Int
    let sizes: [Size]
    let text: String

    enum CodingKeys: String, CodingKey {
        case albumID = "album_id"
        case date, id
        case ownerID = "owner_id"
        case hasTags = "has_tags"
        case lat, long
        case postID = "post_id"
        case sizes, text
    }

    init(albumID: Int, date: Int, id: Int, ownerID: Int, hasTags: Bool, lat: Double, long: Double, postID: Int, sizes: [Size], text: String) {
        self.albumID = albumID
        self.date = date
        self.id = id
        self.ownerID = ownerID
        self.hasTags = hasTags
        self.lat = lat
        self.long = long
        self.postID = postID
        self.sizes = sizes
        self.text = text
    }
}

// MARK: - Size
class Size: Codable {
    let height: Int
    let url: String
    let type: String
    let width: Int

    init(height: Int, url: String, type: String, width: Int) {
        self.height = height
        self.url = url
        self.type = type
        self.width = width
    }
}

// MARK: - LastSeen
class LastSeen: Codable {
    let platform, time: Int

    init(platform: Int, time: Int) {
        self.platform = platform
        self.time = time
    }
}

// MARK: - Personal
class Personal: Codable {
    let alcohol: Int
    let inspiredBy: String
    let langs: [String]
    let lifeMain, peopleMain: Int
    let religion: String
    let religionID, smoking: Int

    enum CodingKeys: String, CodingKey {
        case alcohol
        case inspiredBy = "inspired_by"
        case langs
        case lifeMain = "life_main"
        case peopleMain = "people_main"
        case religion
        case religionID = "religion_id"
        case smoking
    }

    init(alcohol: Int, inspiredBy: String, langs: [String], lifeMain: Int, peopleMain: Int, religion: String, religionID: Int, smoking: Int) {
        self.alcohol = alcohol
        self.inspiredBy = inspiredBy
        self.langs = langs
        self.lifeMain = lifeMain
        self.peopleMain = peopleMain
        self.religion = religion
        self.religionID = religionID
        self.smoking = smoking
    }
}

// MARK: - Relative
class Relative: Codable {
    let type: String
    let id: Int
    let name: String?

    init(type: String, id: Int, name: String?) {
        self.type = type
        self.id = id
        self.name = name
    }
}

// MARK: - School
class School: Codable {
    let city: Int
    let schoolClass: String
    let country: Int
    let id, name: String
    let yearFrom, yearGraduated, yearTo: Int

    enum CodingKeys: String, CodingKey {
        case city
        case schoolClass = "class"
        case country, id, name
        case yearFrom = "year_from"
        case yearGraduated = "year_graduated"
        case yearTo = "year_to"
    }

    init(city: Int, schoolClass: String, country: Int, id: String, name: String, yearFrom: Int, yearGraduated: Int, yearTo: Int) {
        self.city = city
        self.schoolClass = schoolClass
        self.country = country
        self.id = id
        self.name = name
        self.yearFrom = yearFrom
        self.yearGraduated = yearGraduated
        self.yearTo = yearTo
    }
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}

class JSONCodingKey: CodingKey {
    let key: String

    required init?(intValue: Int) {
        return nil
    }

    required init?(stringValue: String) {
        key = stringValue
    }

    var intValue: Int? {
        return nil
    }

    var stringValue: String {
        return key
    }
}

class JSONAny: Codable {

    let value: Any

    static func decodingError(forCodingPath codingPath: [CodingKey]) -> DecodingError {
        let context = DecodingError.Context(codingPath: codingPath, debugDescription: "Cannot decode JSONAny")
        return DecodingError.typeMismatch(JSONAny.self, context)
    }

    static func encodingError(forValue value: Any, codingPath: [CodingKey]) -> EncodingError {
        let context = EncodingError.Context(codingPath: codingPath, debugDescription: "Cannot encode JSONAny")
        return EncodingError.invalidValue(value, context)
    }

    static func decode(from container: SingleValueDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if container.decodeNil() {
            return JSONNull()
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout UnkeyedDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if let value = try? container.decodeNil() {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer() {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout KeyedDecodingContainer<JSONCodingKey>, forKey key: JSONCodingKey) throws -> Any {
        if let value = try? container.decode(Bool.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Int64.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Double.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(String.self, forKey: key) {
            return value
        }
        if let value = try? container.decodeNil(forKey: key) {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer(forKey: key) {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decodeArray(from container: inout UnkeyedDecodingContainer) throws -> [Any] {
        var arr: [Any] = []
        while !container.isAtEnd {
            let value = try decode(from: &container)
            arr.append(value)
        }
        return arr
    }

    static func decodeDictionary(from container: inout KeyedDecodingContainer<JSONCodingKey>) throws -> [String: Any] {
        var dict = [String: Any]()
        for key in container.allKeys {
            let value = try decode(from: &container, forKey: key)
            dict[key.stringValue] = value
        }
        return dict
    }

    static func encode(to container: inout UnkeyedEncodingContainer, array: [Any]) throws {
        for value in array {
            if let value = value as? Bool {
                try container.encode(value)
            } else if let value = value as? Int64 {
                try container.encode(value)
            } else if let value = value as? Double {
                try container.encode(value)
            } else if let value = value as? String {
                try container.encode(value)
            } else if value is JSONNull {
                try container.encodeNil()
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer()
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }

    static func encode(to container: inout KeyedEncodingContainer<JSONCodingKey>, dictionary: [String: Any]) throws {
        for (key, value) in dictionary {
            let key = JSONCodingKey(stringValue: key)!
            if let value = value as? Bool {
                try container.encode(value, forKey: key)
            } else if let value = value as? Int64 {
                try container.encode(value, forKey: key)
            } else if let value = value as? Double {
                try container.encode(value, forKey: key)
            } else if let value = value as? String {
                try container.encode(value, forKey: key)
            } else if value is JSONNull {
                try container.encodeNil(forKey: key)
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer(forKey: key)
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }

    static func encode(to container: inout SingleValueEncodingContainer, value: Any) throws {
        if let value = value as? Bool {
            try container.encode(value)
        } else if let value = value as? Int64 {
            try container.encode(value)
        } else if let value = value as? Double {
            try container.encode(value)
        } else if let value = value as? String {
            try container.encode(value)
        } else if value is JSONNull {
            try container.encodeNil()
        } else {
            throw encodingError(forValue: value, codingPath: container.codingPath)
        }
    }

    public required init(from decoder: Decoder) throws {
        if var arrayContainer = try? decoder.unkeyedContainer() {
            self.value = try JSONAny.decodeArray(from: &arrayContainer)
        } else if var container = try? decoder.container(keyedBy: JSONCodingKey.self) {
            self.value = try JSONAny.decodeDictionary(from: &container)
        } else {
            let container = try decoder.singleValueContainer()
            self.value = try JSONAny.decode(from: container)
        }
    }

    public func encode(to encoder: Encoder) throws {
        if let arr = self.value as? [Any] {
            var container = encoder.unkeyedContainer()
            try JSONAny.encode(to: &container, array: arr)
        } else if let dict = self.value as? [String: Any] {
            var container = encoder.container(keyedBy: JSONCodingKey.self)
            try JSONAny.encode(to: &container, dictionary: dict)
        } else {
            var container = encoder.singleValueContainer()
            try JSONAny.encode(to: &container, value: self.value)
        }
    }
}
