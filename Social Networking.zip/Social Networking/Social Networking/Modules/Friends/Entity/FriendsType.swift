//
//  FriendsType.swift
//  Social Networking
//
//  Created by Anastas Smekh on 06.03.2021.
//

import Foundation

/*
 Тип друзей
 */
enum FriendsType: Int, CaseIterable {
    case best, all
}
