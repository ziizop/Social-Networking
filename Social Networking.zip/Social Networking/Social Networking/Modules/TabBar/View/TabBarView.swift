import UIKit

protocol TabBarViewOutput {
    func viewDidLoad()
}

protocol TabBarViewInput: class {
    
}

final class TabBarView : UITabBarController {
    
    var presetner: TabBarViewOutput?
    
    var token: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presetner?.viewDidLoad()
        configure()
        setTabBar()
    }
    
    init(_ tokens: String) {
        token = tokens
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configure() {
        
        if #available(iOS 13.0, *) {
            view.backgroundColor = .systemBackground
        } else {
            view.backgroundColor = .white
        }
        self.navigationItem.hidesBackButton = true
    }
    
    private func setTabBar() {
        
        let newsModel = NewsAssembly.assembly(token)
        newsModel.tabBarItem = UITabBarItem(title: "Новости", image: UIImage(named: "book"), selectedImage: nil)
        
        
        let friendsModel = FriendsAssembly.assembly()
        friendsModel.tabBarItem = UITabBarItem(title: "Друзья", image: UIImage(named: "person.2"), selectedImage: nil)
        
        let profilModel = ProfileAssembly.assembly()
        profilModel.tabBarItem = UITabBarItem(title: "Профиль", image: UIImage(named: "default_pic") , selectedImage: nil)
        
        viewControllers = [
            newsModel,
            friendsModel,
            profilModel
        ]
    }
}

extension TabBarView: TabBarViewInput {
    
}
