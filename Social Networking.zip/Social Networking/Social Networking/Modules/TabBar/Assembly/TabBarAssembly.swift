import UIKit

final class TabBarAssembly {
    
    static func assembly(news: String) -> UIViewController {
        var view = TabBarView(news)
        var presenter = TabBarPresenter()
        var interactor = TabBarInteractor()
        var router = TabBarRouter()
        
        view.presetner = presenter
        
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        
        interactor.presenter = presenter
        
        router.view = view
        
        return view
    }
}
